#!/bin/bash

#--restart-app     : restart app
#--deploy-js       : deploy js
#--deploy-app      : deploy app
#--flush-redis     : flush redis
#--clear-data      : clear data
#--update-template : update template
#--app-version     : app version
#--webadmin-js     : webamdin js
#--DeployApiRegister : deploy api-reigster
#--ApiRegisterVersion : version for deploy register
running=0
INVENTORY=/opt/deploy/inventory/inventory.py
MAIN_PLAYBOOK=/opt/deploy/playbook/main.yml


mkdir -p ./procedure
deploy_time=./procedure/$(date +%s).procedure
for x in ${@}; do
  if [[ -n "$(echo ${x} | sed  -nr 's/^--AppAction=.*$/OK/p')" ]]; then
        action=$(echo $x | awk -F'=' '{print $2}')
        if [[ -n ${action} ]] ; then
          echo "APP_ACTION: ${action}" >> ${deploy_time}
          running=1
        fi
  elif [[ -n "$(echo ${x} | sed  -nr 's/^--DeployWebAdminJs$/OK/p')" ]]; then
        echo DEPLOY_WEBADMIN_JS: True >> ${deploy_time}
        running=1
  elif [[ -n "$(echo ${x} | sed  -nr 's/^--DeployApp$/OK/p')" ]]; then
        echo DEPLOY_APP: True >> ${deploy_time}
        running=1
  elif [[ -n "$(echo ${x} | sed  -nr 's/^--FlushRedis$/OK/p')" ]]; then
        echo FLUSH_REDIS: True >> ${deploy_time}
        running=1
  elif [[ -n "$(echo ${x} | sed  -nr 's/^--ClearData$/OK/p')" ]]; then
        echo CLEAR_DATA: True >> ${deploy_time}
        running=1
  elif [[ -n "$(echo ${x} | sed  -nr 's/^--DeployApiRegister$/OK/p')" ]]; then
          echo DEPLOY_API_REGISTER: True >> ${deploy_time}
          running=1
  elif [[ -n "$(echo ${x} | sed  -nr 's/^--AppVersion=.*$/OK/p')" ]]; then
        version=$(echo ${x} | awk -F'=' '{print $2}')
        if [[ -n ${version} ]] ; then
                echo APP_VERSION: ${version} >> ${deploy_time}
                running=1
        fi  
  elif [[ -n "$(echo ${x} | sed  -nr 's/^--WebAdminJsVersion=.*$/OK/p')" ]]; then
        version=$(echo ${x} | awk -F'=' '{print $2}')
       if [[ -n ${version} ]]; then
                 version=$(echo ${x} | awk -F'=' '')
                echo WEBADMIN_JS_VERSION: ${version} >> ${deploy_time}
                running=1
        fi
    elif [[ -n "$(echo ${x} | sed  -nr 's/^--ApiRegisterVersion=.*$/OK/p')" ]]; then
       version=$(echo ${x} | awk -F'=' '{print $2}')
       if [[ -n ${version} ]]; then
                 version=$(echo ${x} | awk -F'=' '')
                echo WEBADMIN_JS_VERSION: ${version} >> ${deploy_time}
                running=1
        fi
  else
        echo "not match "
  fi
done
if [[ ${running} -eq 1 ]]; then
echo deploy_time: $(date +%s) >> ${deploy_time}
ansible-playbook  -i  ${INVENTORY}  ${MAIN_PLAYBOOK} --extra-vars "@${deploy_time}"  --user=chr  --extra-var "ansible_ssh_private_key_file=/opt/deploy/chr.private"
fi

