#!/bin/bash
SERVICE=$1
# MODE check service in BACKUP OR FAULT STATE
MODE=$2
COUNTER_FILE="/etc/keepalived/COUNTER"
LAST_SEEN="/etc/keepalived/LAST_SEEN_${SERVICE}"
OLD_STATE=$(cat ${COUNTER_FILE} | sed -nr "s/[A-Z]+-->([A-Z]+)\|${SERVICE} .*$/\1/p" | tail -n 1 )
function check_process() {
        #PROCESS=$( ps -ef  | grep -v "grep\|check_script\|notify" | grep nginx)
        PROCESS=$(ps -aux | grep -P "\b${PID_FILE}\b" | sed -nr "s/^.*java.*DAPP_NAME="${SERVICE}"\s+.*/OK/p")
        if [[ -n ${PROCESS} ]]; then
                echo ${PROCESS} >> /tmp/test
                echo $(date  +%s) > ${LAST_SEEN}
                return 0
        fi
        return 1
}

function check_fault() {
        STOP_TIME=$(cat ${LAST_SEEN} )
        if [ -z ${STOP_TIME} ]; then
                last_stop=0
        else
                last_stop=${STOP_TIME}
        fi
        now_timestamp=$(date +%s)
        diff_time=$(( now_timestamp - last_stop ))
        if [[ ${diff_time} -ge 120 ]] ; then
                return 0
        else
                return 1
        fi
}

if [[ ${MODE} == "BACKUP" ]]; then
        check_process
        exit $?
elif  [[ ${MODE} == "FAULT" ]]; then
        check_process
        rtn_process=$?
        check_fault
        rtn_fault=$?
        if [[ ${rtn_process}  -eq 0 ]] ; then
                if [[ ${OLD_STATE} == "BACKUP" ]]; then
                        exit ${rtn_fault}
                fi
                exit ${rtn_process}
        else
                if [[ ${OLD_STATE} == "MASTER" ]] && [[ ${rtn_fault} -ne 0 ]] ; then
                        exit ${rtn_process}
                fi
                exit ${rtn_fault}
        fi
else
        echo "Unknown variable"
        exit 0
fi