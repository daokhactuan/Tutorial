#!/bin/bash
# this script monitor   server on server
# process infor  PROCESS_NAME -- mode runing -- APPID -- CPU -- MEM --

JavaServiceList="$HOME/.JAVAserviceList"
Thirdparty="$HOME/.Thirdparty"

function check_java(){
LOG_DIR=/opt/ams/logs
A_P_list="server customer payment wallet"

list=$(ps -aux | sed -nr 's/^.*java.*DAPP_NAME=([a-zA-Z0-9_.-]+)\s+.*/\1/p')
ps -aux  | sed -nr "s/[a-z+.]+\s*([0-9]+)\s*([0-9.]+)\s*([0-9.]+).*java.*DAPP_NAME=(.*)\s+.*DAPP_ID=([0-9]+).*/$(hostname -i) -- APP_NAME:\4 -- <<\4-mode>> -- APP_ID:\5 -- PID:\1 -- CPU:\2 --MEM:\3/p" > ${JavaServiceList}
if [[ ! -s ${JavaServiceList} ]] ; then
                return 0
fi

for x in ${list}; do
        mode="RUNNING"

        rtn=$(echo "${A_P_list}" | grep "\b$x\b" >/dev/null; echo  $?)
        if [ ${rtn} -eq 0 ] ; then
                status=$(tail -n 500 ${LOG_DIR}/$x/log/$x.$(date +%Y-%m-%d).log | grep "start to re.* lock:" | tail -n 1 | sed -nr 's/^.*status:\s+([A-Z]+).*$/\1/p')
                if [ "${status}" == "RETRYING" ] ; then
                        mode="SLAVE"
                elif [ "${status}" == "LOCKED" ] ; then
                        mode="MASTER"
                else
                        mode="UNKNOWN"
                fi
        fi
        sed -i "s/<<$x-mode>>/${mode}/g" ${JavaServiceList}

done
cat ${JavaServiceList}
}

function check_party(){
        Servicelist="mysqlrouter redis-server redis-sentinel "
        >  ${Thirdparty}
        for x in ${Servicelist}; do
                ps -aux|    grep  ${x}| grep -v "grep\|sed" | sed -nr "s/[a-z+.]+\s*([0-9]+)\s*([0-9.]+)\s*([0-9.]+).*${x}.*/$(hostname -i) -- APP_NAME:${x} -- PID:\1 -- CPU:\2 --MEM:\3 /p"| grep -v "grep\|sed" >> ${Thirdparty}
                sed -i "s/<<$x-mode>>/${mode}/g" ${Thirdparty}

        done
        cat   ${Thirdparty}
}



check_party
check_java
if  [[ ! -s ${JavaServiceList}   ]]  && [[ ! -s ${Thirdparty}  ]]; then
      echo "There is no process running "
fi
