#!/bin/bash
# lock file is using for , some service not start at time
SERVICE=$1
STATE=$2
LOCK_FILE=/opt/ams/logs/${SERVICE}/${SERVICE}_IS_LOCKED
COUNTER_FILE=/etc/keepalived/COUNTER
BIN_DIR=/opt/ams/app/bin
APP_USER=ams.service
OLD_STATE=$(cat ${COUNTER_FILE} | sed -nr "s/[A-Z]+-->([A-Z]+)\|${SERVICE} .*$/\1/p" | tail -n 1 )

if [[ ${STATE} == "MASTER" ]]; then

        if [ -f ${LOCK_FILE} ]; then
                echo "${SERVICE}:FAULT not started  because  locked exsit: ${LOCK_FILE} ::: $(date)" >> ${COUNTER_FILE}
                exit 1
        fi
        if [[ -z ${OLD_STATE} ]]; thendd
                OLD_STATE=BACKUP
        fi
        echo "${OLD_STATE}-->${STATE}|${SERVICE} change to Master state ::: $(date)" >> ${COUNTER_FILE}
        ######################## Master action ########################################################
         /etc/keepalived/B-script.sh ${SERVICE}
        if [[ $? ==1 ]]; then
                su - ${APP_USER} -c "${BIN_DIR}/${SERVICE}.sh stop"
                su - ${APP_USER} -c "${BIN_DIR}/${SERVICE}.sh start"
        fi
elif [[ ${STATE} == "BACKUP" ]]; then
        echo "${OLD_STATE}-->${STATE}|${SERVICE} change to BACKUP state ::: $(date)" >> ${COUNTER_FILE}
        ######################## Backup  action ########################################################
        su - ${APP_USER} -c "${BIN_DIR}/${SERVICE}.sh stop"
else
        echo "${OLD_STATE}-->${STATE}|${SERVICE} change to FAULT ::: $(date)" >> ${COUNTER_FILE}
        /usr/bin/chmod  -x ${BIN_DIR}/${SERVICE}.sh
fi
