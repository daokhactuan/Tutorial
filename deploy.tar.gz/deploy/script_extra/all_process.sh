#!/bin/bash
IP_LIST="aamsfront001 aamsfront002 aamsmdl001   aamsmdl002  aamsmdl003  aamsmdl004  aamsadm001  aamsadm002"



> $HOME/.result
> $HOME/.message
for x in ${IP_LIST}; do
        echo "########################################################################################" >> $HOME/.result

        ssh $x "/home/ams.service/list_process" >> $HOME/.result
done

status=0

cat $HOME/.result
exit ${status}
