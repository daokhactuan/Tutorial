#!/bin/bash
SERVICE=$1
BIN_DIR=/opt/ams/app/bin
stat="/bin/stat --format=%a "
ps="/usr/bin/ps a"
function check_BinFile() {
        BIN_STAT=$(${stat} ${BIN_DIR}/${SERVICE}.sh)
        if  [[ ${BIN_STAT::1} -eq  5 || ${BIN_STAT::1} -eq  7 ]] && [[ ${BIN_STAT:1:1} -eq  5 || ${BIN_STAT:1:1} -eq  7 ]] ; then
                return 0
        fi
        return 1
}


function check_AppRunning() {
        PID_FILE=$(cat /opt/ams/logs/${SERVICE}/${SERVICE}.pid)
        PROCESS=$(ps -aux | grep -P "\b${PID_FILE}\b" | sed -nr "s/^.*java.*DAPP_NAME="${SERVICE}"\s+.*/OK/p")
        if [[ -n ${PROCESS} ]]; then
            if [[ ${rtn_1} -eq 1 ]] ; then
                /usr/bin/chmod  554 ${BIN_DIR}/${SERVICE}.sh
                exit 0
            fi
        fi
        return 1

}
check_BinFile
rtn_1=$?
check_AppRunning
if [[ rtn_1 -eq 0 ]] ;then
        exit 0
fi
exit 1