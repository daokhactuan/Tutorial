#!/bin/bash
SERVICE=$1
BIN_DIR=/opt/ams/app/bin
PID_FILE=$(cat /opt/ams/logs/${SERVICE}/${SERVICE}.pid)
PROCESS=$(ps -aux | grep -P "\b${PID_FILE}\b" | sed -nr "s/^.*java.*DAPP_NAME="${SERVICE}"\s+.*/OK/p")
if [[ -n ${PROCESS} ]]; then
        exit 0
fi
exit 1