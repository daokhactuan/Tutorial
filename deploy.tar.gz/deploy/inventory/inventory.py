#!/usr/bin/python

import os
import yaml
import sys
import argparse
import json

dir_path = os.path.dirname(os.path.realpath(__file__))
hostFile=dir_path + "/hosts.yml"

class LoadInventory(object):
    global serviceFile
    def __init__(self):
        self.inventory = {}
        self.read_cli_args()
        self.inventory = {"_meta": {"hostvars": {} }}
        self.servicesDefined = {}
        self.hostDefined = {}
        # Called with `--list`.
        if self.args.list:
            self.inventory = self.load_inventory()
        # Called with `--host [hostname]`.
        elif self.args.host:
            # Not implemented, since we return _meta info `--list`.
            self.inventory = self.empty_inventory()
        # If no groups or vars are present, return an empty inventory.
        else:
            self.inventory = self.empty_inventory()
        print json.dumps(self.inventory);
    def empty_inventory(self):
        return {'_meta': {'hostvars': {}}}

    # Read the command line args passed to the script.
    def read_cli_args(self):
        parser = argparse.ArgumentParser()
        parser.add_argument('--list', action = 'store_true')
        parser.add_argument('--host', action = 'store')
        self.args = parser.parse_args()

    # add group to inventory
    ####################################################################################################
    def add_group(self, groupName):
      if groupName not in self.inventory.keys(): 
        self.inventory[groupName]= {}

   # add host to hostsList
   ####################################################################################################
    def add_host(self, host, service):
      if "hosts" not in self.inventory[service].keys():
        self.inventory[service]["hosts"]= []
      if host not in self.inventory[service]["hosts"]:
        self.inventory[service]["hosts"].append(host)
      if service  not in  self.inventory["_meta"]["hostvars"][host].keys():
        self.inventory["_meta"]["hostvars"][host][service] = {}
      

    # add children to group
    ####################################################################################################
    def add_children(self, child, parent):
      if child in [ parent ]:
        return 0
      if parent not in self.inventory.keys():
        self.inventory[parent] = {}
      if "children"  not in self.inventory[parent].keys():
        self.inventory[parent]["children"] = []
      if child not in self.inventory[parent]["children"]:
        self.inventory[parent]["children"].append(child)

   # add from HOSTS varitable to groups
   ####################################################################################################
    def add_hosts_variables(self, item):
        if item["name"] not in self.inventory["_meta"]["hostvars"].keys():
            self.inventory["_meta"]["hostvars"][item["name"]]= {}
            self.inventory["_meta"]["hostvars"][item["name"]]["ansible_host"] = item["ssh_ip"]
            for var in item.keys():
              if var  not in ["name", "ssh_ip" ]:
                self.inventory["_meta"]["hostvars"][item["name"]][var]= item[var]   

    # add GROUPS_VARS
    ####################################################################################################
    def  add_groups_vars(self, group):
      # add groups if not exist
      if group  not in self.inventory.keys():
        self.add_group(group["name"])
        self.inventory[group["name"]]["vars"] = {}
      for var in group.keys():
        if var not in ["name", "ssh_ip" , "label"]:
          if "label" in group.keys() and group["label"]:
            if group["name"] not in self.inventory[group["name"]]["vars"].keys():
              self.inventory[group["name"]]["vars"][group["name"]] = {}
            self.inventory[group["name"]]["vars"][group["name"]][var] = group[var]
          else:
            self.inventory[group["name"]]["vars"][var] = group[var]

    # add host to group from SERVICES
    ####################################################################################################
    def add_hosts_to_group(self, item):
      for i in item["hosts"]:
        self.add_host(i["host"], item["name"])
        self.add_children(item["name"], "all")
        
        if "sourceName" in item.keys():
          self.add_children(item["name"], item["sourceName"])
          self.add_children(item["sourceName"], "all")
        #  self.add_host(i["host"], item["sourceName"])

    # add host to group from SERVICES
    ####################################################################################################
    def add_vars_to_group(self, item):
      if "vars" not in self.inventory[item["name"]].keys():
        self.inventory[item["name"]]["vars"] = {}
      for var in item.keys():
        if var  not in ["name", "ssh_ip" , "label" , "hosts"]:
              self.inventory[item["name"]]["vars"][item["name"]] = {}
              self.inventory[item["name"]]["vars"][item["name"]][var] = item[var]
    
    # add variable for each host from SERVICES
    ####################################################################################################
    def add_vars_to_hosts(self, item):
      for i in item["hosts"]:
        for var in item.keys():
          if var not in  ["name", "ssh_ip" , "label", "host" ,"hosts" ,"sourceName" ]:
            self.inventory["_meta"]["hostvars"][i["host"]][item["name"]][var] = item[var]
        for var in i.keys():
          if var  not in ["name", "ssh_ip" , "label", "host" ,"hosts" , "sourceName" ]:
            self.inventory["_meta"]["hostvars"][i["host"]][item["name"]][var] = i[var]
        

    # Load data from file
    ####################################################################################################
    def loadService(self, file):
        with open(file, 'r') as file_descriptor:
             data =  yaml.load(file_descriptor)
        return data


    def load_inventory(self):
        self.hostDefined = self.loadService(hostFile)

        # create host with alias name
        for host in self.hostDefined["HOSTS"]:
            self.add_hosts_variables(host)   


        # add service group vs variable 
        self.add_group("all")
        if "SERVICES" in self.hostDefined.keys():
          for service in self.hostDefined["SERVICES"]:
            self.add_group(service["name"])
            if "sourceName" in service.keys():
              self.add_group(service["sourceName"])
            self.add_hosts_to_group(service)
            self.add_vars_to_hosts(service)
          #  self.add_vars_to_group(service)

        # adding groups var in GROUPS_VARS
        if "GROUPS_VARS" in self.hostDefined.keys():
          for group in self.hostDefined["GROUPS_VARS"]:
            group['inventory_dir'] = dir_path
            self.add_groups_vars(group)

        return self.inventory
LoadInventory()
