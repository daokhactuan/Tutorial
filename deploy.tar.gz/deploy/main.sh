#!/bin/bash

#--restart-app     : restart app
#--deploy-js       : deploy js
#--deploy-app      : deploy app
#--flush-redis     : flush redis
#--clear-data      : clear data
#--update-template : update template
#--app-version     : app version
#--webadmin-js     : webamdin js
running=0
unset RESTART_APP
unset DEPLOY_JS
unset DEPLOY_APP
unset FLUSH_REDIS
unset CLEAR_DATA
unset UPDATE_TEMPLATE
unset APP_VERSION
unset WEBADMIN_JS_VERSION
mkdir -p ./procedure
deploy_time=./procedure/$(date +%s).procedure
for x in ${@}; do
  if [[ -n "$(echo ${x} | sed  -nr 's/^--restart-app$/OK/p')" ]]; then
        echo  RESTART_APP: True>> ${deploy_time}
        running=1
  elif [[ -n "$(echo ${x} | sed  -nr 's/^--deploy-js$/OK/p')" ]]; then
        echo DEPLOY_JS: True >> ${deploy_time}
        running=1
  elif [[ -n "$(echo ${x} | sed  -nr 's/^--deploy-app$/OK/p')" ]]; then
        echo DEPLOY_APP: True >> ${deploy_time}
        running=1
  elif [[ -n "$(echo ${x} | sed  -nr 's/^--flush-redis$/OK/p')" ]]; then
        echo FLUSH_REDIS: True >> ${deploy_time}
        running=1
  elif [[ -n "$(echo ${x} | sed  -nr 's/^--clear-data$/OK/p')" ]]; then
        echo CLEAR_DATA: True >> ${deploy_time}
        running=1
  elif [[ -n "$(echo ${x} | sed  -nr 's/^--update-template$/OK/p')" ]]; then
        echo  UPDATE_TEMPLATE: True >> ${deploy_time}
        running=1
  elif [[ -n "$(echo ${x} | sed  -nr 's/^--app-version$/OK/p')" ]]; then
        version=$(echo ${x} | awk -F'=' '')
        if [[ -n ${version} ]] ; then
                echo APP_VERSION: ${version} >> ${deploy_time}
                running=1
        fi
  elif [[ -n "$(echo ${x} | sed  -nr 's/^--webadmin-js$/OK/p')" ]]; then
       if [[ -n ${version} ]]; then
                 version=$(echo ${x} | awk -F'=' '')
                echo WEBADMIN_JS_VERSION: ${version} >> deploy_time
                running=1
        fi
  else
        echo "not match "
  fi
done

if [[ ${running} -eq 1 ]]; then
ansible-playbook -i  /home/ams.service/lastest/hosts/STG/inventory.py /home/ams.service/lastest/playbook/main.yml  --extra-vars "@${deploy_time}" --ask-pass 
fi
