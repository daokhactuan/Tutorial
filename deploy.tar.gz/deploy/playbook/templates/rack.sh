#!/bin/bash
# LockG
CURRENT_FOLDER=$(readlink  -f ${APP_HOME})
APP_VERSION=$(echo ${CURRENT_FOLDER} | awk -F'/' '{print $NF}' | sed -nr 's/app.(.*)/\1/p' )
JAVA_11_PACKAGE="--add-opens=java.base/java.nio=ALL-UNNAMED --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.lang.invoke=ALL-UNNAMED --add-opens=java.base/sun.nio.ch=ALL-UNNAMED --add-opens=jdk.unsupported/sun.misc=ALL-UNNAMED --add-opens=java.base/jdk.internal.ref=ALL-UNNAMED --add-opens=java.base/jdk.internal.misc=ALL-UNNAMED --add-opens=java.base/sun.security.util=ALL-UNNAMED --add-opens=java.base/sun.security.x509=ALL-UNNAMED --add-opens=java.xml/com.sun.org.apache.xpath.internal=ALL-UNNAMED --add-opens=java.xml/com.sun.org.apache.xml.internal.utils=ALL-UNNAMED"
function lock(){
_action="$1"
_logFile="/tmp/${APP_NAME}.lock"
if [ "${_action}" = "check" ];
then
        if [ -e "${_logFile}" ];
        then
                echo "${APP_NAME} already running , or please delete lockFile ${_logFile} ";
                exit 1;
        else
                touch ${_logFile};
        fi
fi

if [ "${_action}" = "delete" ];
then
        rm -f ${_logFile};
        exit 0;
fi
}

function checkHA(){
_masterKey="LOCKED"
_slaveKey="RETRYING"
_getKey=$(grep "\[HA\]start to" ${BASE_DIR}/logs/${APP_NAME}/log/${APP_NAME}.`date +"%F"`.log | tail -n1 | awk -F':' '{print $6}' | sed 's# ##g')

if [ "${_getKey}" = "${_masterKey}" ];
then
        _haStatus="master";
fi

if [ "${_getKey}" = "${_slaveKey}" ];
then
        _haStatus="slave";
fi
}

function checkStart(){
echo "${APP_NAME} start begin ."
while (true)
do
        _dateCur=`date +"%y-%m-%d %H:%M:%S"`
        _date1Age=`date +"%y-%m-%d %H:%M:%S" -d "-1 sec"`
        case ${APP_NAME} in
                replicator|mgrapiEx)
                        grep -E "^${_dateCur}|^${_date1Age}" ${BASE_DIR}/logs/${APP_NAME}/log/${APP_NAME}.`date +"%F"`.log |grep -q 'was successfully started'
                        ;;
                *)
        esac
        if [ "$?" -eq 0 ];
        then
                echo "${APP_NAME} start finish ."
                break 1;
        fi
        sleep 1s;
done
}

function start(){
#class path
CLASSPATH=$APP_HOME/conf
for x in  `ls $APP_HOME/lib/` ; do CLASSPATH=$CLASSPATH:$APP_HOME/lib/$x;done
for x in  `ls $APP_HOME/dep/` ; do CLASSPATH=$CLASSPATH:$APP_HOME/dep/$x;done
export CLASSPATH

#args
case ${APP_NAME} in
        payment|wallet|batch|server|customer)
                ARGS="-Xms${MIN_MEMORY} -Xmx${MAX_MEMORY} -XX:PermSize=${MIN_PermSize} -XX:MaxPermSize=${MAX_PermSize} -XX:+AggressiveOpts -XX:+UseParallelGC  -verbose:gc -XX:+HeapDumpOnOutOfMemoryError -Djava.net.preferIPv4Stack=true -Djgroups.bind_addr=${APP_IP} -XX:MaxDirectMemorySize=1024M -XX:SurvivorRatio=18 -XX:TargetSurvivorRatio=80"
                ;;
        replicator)
                ARGS="-Xms${MIN_MEMORY} -Xmx${MAX_MEMORY} -XX:PermSize=${MIN_PermSize} -XX:MaxPermSize=${MAX_PermSize}"
                ;;
        *)
                ARGS="-Xms${MIN_MEMORY} -Xmx${MAX_MEMORY} -XX:PermSize=${MIN_PermSize} -XX:MaxPermSize=${MAX_PermSize} -XX:+AggressiveOpts -XX:+UseParallelGC  -verbose:gc -XX:+HeapDumpOnOutOfMemoryError -Djava.net.preferIPv4Stack=true"
                ;;
esac

case ${APP_NAME} in
        replicator)
                /usr/bin/nohup java -server -DAPP_HOME=${APP_HOME} -DAPP_VERSION=${APP_VERSION}  -DAPP_NAME=${APP_NAME} -Denv=${ENV} -DLOGGING_HOST=127.0.0.1 -DLOGGING_PORT=514  -Djgroups.bind_addr=${APP_IP}  ${ARGS} ${LAUNCH_TARGET}  >  ${BASE_DIR}/logs/${APP_NAME}/log/${APP_NAME}.out  &
                ;;
        *)
                /usr/bin/nohup java -server  -DAPP_HOME=${APP_HOME} -DAPP_VERSION=${APP_VERSION}  -DAPP_NAME=${APP_NAME} -DAPP_ID=${APP_ID} -Denv=${ENV}  -DLOGGING_HOST=127.0.0.1 -DLOGGING_PORT=514 -Djgroups.bind_addr=${APP_IP} ${JAVA_11_PACKAGE} ${ARGS} ${LAUNCH_TARGET}  >  ${BASE_DIR}/logs/${APP_NAME}/log/${APP_NAME}.out  &
                ;;
esac
}

function stop(){
_pidList=`ps -ef | grep ${LAUNCH_TARGET} | grep -v grep | awk '{ print $2 }'`
if [ -n "${_pidList}" ];
then
        for _pid in ${_pidList};
        do
                kill -9 ${_pid};
        done
        mv ${BASE_DIR}/logs/${APP_NAME}/log/${APP_NAME}.out ${BASE_DIR}/logs/${APP_NAME}/log/${APP_NAME}.`date +%s`.out
fi
}

function status(){
_processCount=`ps -ef | grep ${LAUNCH_TARGET} | grep -vc grep`
if [ "${_processCount}" -eq 1 ];
then
        case ${APP_NAME} in
                server|mtgw|trader|feeder|eagw|admapi)
                        checkHA;
                        echo -e "${APP_NAME} \e[33m${_haStatus}\e[0m \e[31malready\e[0m running....";
                        ;;
                *)
                        echo -e "${APP_NAME} \e[32malready\e[0m running....";
                        ;;
        esac
else
        echo -e "${APP_NAME} \e[31mnot\e[0m running....";
fi
}
function makePID(){
        _pidList=`ps -ef | grep "DAPP_NAME=${APP_NAME}" | grep -v grep | awk '{ print $2 }'`
        echo ${_pidList} > /tmp/${APP_NAME}.pid
}

case "$1" in
        start)
                lock check;
                start;
                sleep 1s;
                checkStart;
                makePID
                ;;
        stop)
                stop;
                lock delete;
                rm  /tmp/${LAUNCH_TARGET}.pid
                ;;
        status)
                status;
                ;;
        *)
                echo "Usage: $0 {start|stop|status}";
                ;;
esac

